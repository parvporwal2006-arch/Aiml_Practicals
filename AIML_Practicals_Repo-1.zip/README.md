# AIML Practicals

Code and output for all 10 AIML practicals.

Run each program from inside the `code/` folder (plots are saved to `../output/`).

| # | Practical | Code | Output |
|---|-----------|------|--------|
| 1 | Association between variables (correlation, diabetes dataset) | [p1_association.py](code/p1_association.py) | [text](output/p1_output.txt), [heatmap](output/p1_heatmap.png), [scatter](output/p1_scatter.png) |
| 2 | Clustering (KMeans + Agglomerative) | [p2_clustering.py](code/p2_clustering.py) | [text](output/p2_output.txt), [plot](output/p2_clusters.png) |
| 3 | Dimensionality reduction (PCA) | [p3_pca.py](code/p3_pca.py) | [text](output/p3_output.txt), [plot](output/p3_pca.png) |
| 4 | Naive Bayes classification | [p4_naive_bayes.py](code/p4_naive_bayes.py) | [text](output/p4_output.txt), [plot](output/p4_confusion.png) |
| 5 | KNN classification | [p5_knn.py](code/p5_knn.py) | [text](output/p5_output.txt), [plot](output/p5_knn_k.png) |
| 6 | Linear regression | [p6_linear_regression.py](code/p6_linear_regression.py) | [text](output/p6_output.txt), [plot](output/p6_regression.png) |
| 7 | Support Vector Regression | [p7_svr.py](code/p7_svr.py) | [text](output/p7_output.txt), [plot](output/p7_svr_kernels.png) |
| 8 | Regularization (Ridge and Lasso) | [p8_regularization.py](code/p8_regularization.py) | [text](output/p8_output.txt), [plot](output/p8_regularization.png) |
| 9 | Object detection from CCTV footage | [p9_cctv_detection.py](code/p9_cctv_detection.py) | [text](output/p9_output.txt), [frames](output/p9_frames.png) |
| 10 | Fake news detection (text + image) | [p10_fake_news.py](code/p10_fake_news.py) | [text](output/p10_output.txt), [plot](output/p10_compare.png) |

## Requirements
```
pip install numpy pandas matplotlib scipy scikit-learn opencv-python
```
