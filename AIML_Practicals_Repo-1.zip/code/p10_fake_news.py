# Practical 10 - fake news detection from multimodal data (text + image)
# NOTE: this is a small demo dataset so that the program runs anywhere.
# Text = headlines written by hand. Image = 3 numbers per picture, the kind of
# values a CNN / forensic tool would give (see column names). With a real
# dataset (e.g. Fakeddit) you would replace these numbers with CNN features.

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.pipeline import make_pipeline
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix

real = [
    "Government announces new scholarship scheme for engineering students",
    "City council approves budget for road repair this year",
    "Local team wins district cricket tournament after final match",
    "Scientists publish study on rising sea levels in coastal areas",
    "Railway ministry adds two new express trains on southern route",
    "Central bank keeps interest rates unchanged in monthly review",
    "University opens applications for the next academic session",
    "Health department begins free vaccination camp in rural districts",
    "Heavy rain expected in the region over the next two days says weather office",
    "Company reports quarterly profit growth of six percent",
    "Metro line extension to open for commuters next month",
    "Students win national robotics competition held in Pune",
    "Farmers receive crop insurance payments after last season",
    "Court hears arguments in the long running land dispute case",
    "New library inaugurated in the town with thousands of books",
    "Airport authority says passenger traffic rose compared to last year",
    "Researchers develop low cost water filter for villages",
    "State board declares class twelve results on official website",
    "Power cut planned on Sunday for maintenance work in sector four",
    "Police arrest suspect in connection with market theft after investigation",
    "Exports increased during the last quarter according to commerce data",
    "Museum to display ancient coins found during excavation",
    "Hospital adds new ward to handle seasonal fever cases",
    "Tech firm launches internship programme for final year students",
]
fake = [
    "SHOCKING: Doctors hate this one trick that cures every disease overnight",
    "Aliens land in the capital and government hides the truth from you",
    "Drinking hot water destroys the virus in seconds, share before it is deleted",
    "BREAKING!!! Free mobile phones for everyone, click the link now",
    "Celebrity secretly died last night and media is lying to the public",
    "Scientists confirm the moon will disappear next week, panic spreads",
    "You won't believe what this politician did, number five will shock you",
    "Banks will close for ten days and all your money will be gone forward this",
    "Miracle fruit makes you lose twenty kilos in three days guaranteed",
    "Secret video leaked proves election was completely fake, forward to all",
    "Government to put chips in every currency note, insiders reveal",
    "Man lives without food for ten years says viral post, doctors stunned",
    "Whatsapp will start charging money from tomorrow, send this to ten friends",
    "Earthquake predicted for tomorrow by psychic, evacuate immediately",
    "Cheap petrol for only five rupees from tomorrow, official order leaked",
    "Famous cricketer arrested for selling country secrets, shocking photos",
    "This herbal tea cures cancer, big companies are hiding it from you",
    "Giant snake found in the city drain swallows five people, watch video",
    "NASA warns the sun will go dark for three days, stock food now",
    "Exam cancelled for all students nationwide, news channels are hiding it",
    "Unbelievable! Old woman gets younger every day using kitchen ingredient",
    "Rain of gold coins falls on village, thousands rush to collect",
    "Banned video government doesn't want you to see, share fast",
    "Secret law will make travelling free for everybody from next month",
]
texts = real + fake
labels = [0] * len(real) + [1] * len(fake)       # 1 = fake

# fake image features (ela = error-level-analysis score, sharp = edge sharpness, face = faces detected)
rng = np.random.RandomState(4)
n = len(texts)
lab = np.array(labels)
ela = rng.normal(0.30 + 0.12 * lab, 0.12)
sharp = rng.normal(0.55 - 0.08 * lab, 0.15)
face = rng.poisson(1.0 + 0.4 * lab)
df = pd.DataFrame({"text": texts, "ela_score": ela.round(3), "sharpness": sharp.round(3),
                   "n_faces": face, "label": labels})
df.to_csv("../output/p10_dataset.csv", index=False)
print("dataset:", df.shape, " fake =", int(lab.sum()), " real =", int((1 - lab).sum()))

img_cols = ["ela_score", "sharpness", "n_faces"]
y = df["label"].values

# only 48 rows, so one small test split would be very noisy -> use 6-fold cross validation
text_pipe = make_pipeline(TfidfVectorizer(lowercase=True, ngram_range=(1, 2)),
LogisticRegression(max_iter=1000))
img_model = RandomForestClassifier(n_estimators=100, random_state=0)
cv = StratifiedKFold(n_splits=6, shuffle=True, random_state=8)

p_text = cross_val_predict(text_pipe, df["text"], y, cv=cv, method="predict_proba")[:, 1]
p_img = cross_val_predict(img_model, df[img_cols], y, cv=cv, method="predict_proba")[:, 1]

# late fusion: average the two probabilities
p_fused = 0.5 * p_text + 0.5 * p_img

def report(name, p):
    pred = (p >= 0.5).astype(int)
    print(f"{name:22s} accuracy = {accuracy_score(y, pred):.3f}   F1 = {f1_score(y,
pred):.3f}")
    return pred

print()
report("text only", p_text)
report("image only", p_img)
pred = report("multimodal (fusion)", p_fused)
print("\nconfusion matrix (fusion):\n", confusion_matrix(y, pred))

# fit on everything for the final model
text_pipe.fit(df["text"], y)
img_model.fit(df[img_cols], y)

# a new post
new_text = "Shocking secret video leaked, share with everyone before it is deleted"
new_img = pd.DataFrame([[0.47, 0.42, 2]], columns=img_cols)
p = 0.5 * text_pipe.predict_proba([new_text])[0, 1] + 0.5 * img_model.predict_proba(new_img)[0, 1]
print(f"\nnew post -> probability fake = {p:.2f} -> {'FAKE' if p >= 0.5 else 'REAL'}")

plt.figure(figsize=(5.5, 4))
names = ["text", "image", "fusion"]
accs = [accuracy_score(y, (q >= 0.5).astype(int)) for q in (p_text, p_img, p_fused)]
plt.bar(names, accs, color=["#4472c4", "#ed7d31", "#70ad47"])
plt.ylim(0, 1.05)
plt.ylabel("accuracy")
plt.title("Unimodal vs multimodal")
plt.tight_layout()
plt.savefig("../output/p10_compare.png", dpi=130)
