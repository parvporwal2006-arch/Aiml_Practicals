# Practical 1 - association between dependent and independent variables
# dataset: diabetes (comes with sklearn, so no download needed)
# target = disease progression after one year, features = age, bmi, bp, s1..s6

import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.stats import pearsonr
from sklearn.datasets import load_diabetes

data = load_diabetes(as_frame=True)
df = data.frame            # last column 'target' is the dependent variable
print("shape:", df.shape)
print(df.head(), "\n")

# 1. correlation of every independent variable with the target
corr = df.corr()
print("Correlation with target:")
print(corr["target"].drop("target").sort_values(ascending=False).round(3), "\n")

# 2. pearson r and p-value for a few columns
for col in ["bmi", "s5", "bp", "age"]:
    r, p = pearsonr(df[col], df["target"])
    strength = "strong" if abs(r) > 0.5 else "moderate" if abs(r) > 0.3 else "weak"
    print(f"{col:4s} r = {r:6.3f}   p = {p:.2e}   -> {strength}")

# 3. heatmap of the whole correlation matrix
fig, ax = plt.subplots(figsize=(7, 6))
im = ax.imshow(corr, cmap="coolwarm", vmin=-1, vmax=1)
ax.set_xticks(range(len(corr)))
ax.set_yticks(range(len(corr)))
ax.set_xticklabels(corr.columns, rotation=90)
ax.set_yticklabels(corr.columns)
fig.colorbar(im)
ax.set_title("Correlation matrix (diabetes dataset)")
plt.tight_layout()
plt.savefig("../output/p1_heatmap.png", dpi=130)

# 4. scatter plot of the best predictor against target
fig, ax = plt.subplots(figsize=(5.5, 4))
ax.scatter(df["bmi"], df["target"], s=10, alpha=0.6)
ax.set_xlabel("bmi (standardised)")
ax.set_ylabel("disease progression")
ax.set_title("bmi vs target")
plt.tight_layout()
plt.savefig("../output/p1_scatter.png", dpi=130)
