# Practical 2 - clustering with unsupervised learning (KMeans + Agglomerative)
# we pretend we don't know the iris species and see if clustering finds them

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.metrics import silhouette_score, adjusted_rand_score

iris = load_iris()
X = StandardScaler().fit_transform(iris.data)
y_true = iris.target          # only used at the end to check the result

# elbow method - try k from 1 to 8
inertia = []
for k in range(1, 9):
    km = KMeans(n_clusters=k, n_init=10, random_state=42).fit(X)
    inertia.append(km.inertia_)
    if k > 1:
        print(f"k={k}  inertia={km.inertia_:7.2f}  silhouette={silhouette_score(X,
km.labels_):.3f}")

# k = 3 looks fine
km = KMeans(n_clusters=3, n_init=10, random_state=42).fit(X)
print("\nKMeans cluster sizes:", np.bincount(km.labels_))
print("Adjusted Rand index vs real species:", round(adjusted_rand_score(y_true, km.labels_),
3))

agg = AgglomerativeClustering(n_clusters=3, linkage="ward").fit(X)
print("Agglomerative sizes:", np.bincount(agg.labels_))
print("Adjusted Rand index (agglomerative):", round(adjusted_rand_score(y_true, agg.labels_),
3))

fig, ax = plt.subplots(1, 2, figsize=(10, 4))
ax[0].plot(range(1, 9), inertia, "o-")
ax[0].set_xlabel("k")
ax[0].set_ylabel("inertia")
ax[0].set_title("Elbow curve")
ax[1].scatter(X[:, 2], X[:, 3], c=km.labels_, cmap="viridis", s=20)
ax[1].scatter(km.cluster_centers_[:, 2], km.cluster_centers_[:, 3], c="red", marker="X",
s=150)
ax[1].set_xlabel("petal length (scaled)")
ax[1].set_ylabel("petal width (scaled)")
ax[1].set_title("KMeans clusters, k = 3")
plt.tight_layout()
plt.savefig("../output/p2_clusters.png", dpi=130)
