# Practical 3 - dimensionality reduction using PCA
# wine dataset has 13 features, we try to squeeze it down to 2

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.datasets import load_wine
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

wine = load_wine()
X, y = wine.data, wine.target
print("original shape:", X.shape)

# PCA is affected by scale, so standardise first
X_std = StandardScaler().fit_transform(X)

pca_full = PCA().fit(X_std)
ratio = pca_full.explained_variance_ratio_
cum = np.cumsum(ratio)
for i in range(5):
    print(f"PC{i+1}: {ratio[i]*100:5.2f}%   cumulative: {cum[i]*100:5.2f}%")
n95 = int(np.argmax(cum >= 0.95)) + 1
print("components needed for 95% variance:", n95)

pca2 = PCA(n_components=2)
X2 = pca2.fit_transform(X_std)
print("reduced shape:", X2.shape)

# does a classifier still work after the reduction?
def score(data):
    a, b, c, d = train_test_split(data, y, test_size=0.3, random_state=1, stratify=y)
    return LogisticRegression(max_iter=1000).fit(a, c).score(b, d)
print("accuracy with 13 features:", round(score(X_std), 3))
print("accuracy with 2 PCs      :", round(score(X2), 3))

fig, ax = plt.subplots(1, 2, figsize=(10, 4))
ax[0].bar(range(1, 14), ratio)
ax[0].plot(range(1, 14), cum, "r-o")
ax[0].set_xlabel("principal component")
ax[0].set_ylabel("variance explained")
ax[0].set_title("Scree plot")
for cls, name in enumerate(wine.target_names):
    ax[1].scatter(X2[y == cls, 0], X2[y == cls, 1], label=name, s=20)
ax[1].set_xlabel("PC1")
ax[1].set_ylabel("PC2")
ax[1].legend()
ax[1].set_title("Wine data in 2 dimensions")
plt.tight_layout()
plt.savefig("../output/p3_pca.png", dpi=130)
