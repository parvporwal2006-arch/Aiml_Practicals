# Practical 4 - Naive Bayes classification
# GaussianNB on the breast cancer dataset (malignant vs benign)

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

cancer = load_breast_cancer()
X, y = cancer.data, cancer.target
print("samples:", X.shape[0], " features:", X.shape[1])
print("classes:", [str(c) for c in cancer.target_names], " counts:", np.bincount(y))

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=7, stratify=y)

model = GaussianNB()
model.fit(X_train, y_train)

# priors are just the class frequencies in the training data
print("\nprior P(class):", model.class_prior_.round(3))

pred = model.predict(X_test)
print("accuracy:", round(accuracy_score(y_test, pred), 4))
cm = confusion_matrix(y_test, pred)
print("confusion matrix:\n", cm)
print(classification_report(y_test, pred, target_names=cancer.target_names))

# posterior probability for the first test sample
p = model.predict_proba(X_test[:1])[0]
print(f"sample 0 -> P(malignant)={p[0]:.4f}  P(benign)={p[1]:.4f}  actual={cancer.target_names[y_test[0]]}")

fig, ax = plt.subplots(figsize=(4.5, 4))
ax.imshow(cm, cmap="Blues")
for i in range(2):
    for j in range(2):
        ax.text(j, i, cm[i, j], ha="center", va="center", fontsize=14)
ax.set_xticks([0, 1]); ax.set_yticks([0, 1])
ax.set_xticklabels(cancer.target_names); ax.set_yticklabels(cancer.target_names)
ax.set_xlabel("predicted"); ax.set_ylabel("actual")
ax.set_title("Naive Bayes confusion matrix")
plt.tight_layout()
plt.savefig("../output/p4_confusion.png", dpi=130)
