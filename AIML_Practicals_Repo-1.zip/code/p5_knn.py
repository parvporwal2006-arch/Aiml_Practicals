# Practical 5 - KNN classification (iris dataset)

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, confusion_matrix

iris = load_iris()
X_train, X_test, y_train, y_test = train_test_split(
    iris.data, iris.target, test_size=0.2, random_state=42, stratify=iris.target)

# KNN works on distances so features must be on the same scale
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)

# find a good k using 5-fold cross validation (odd values to avoid ties)
ks = list(range(1, 22, 2))
cv_scores = []
for k in ks:
    s = cross_val_score(KNeighborsClassifier(n_neighbors=k), X_train, y_train, cv=5).mean()
    cv_scores.append(s)
    print(f"k = {k:2d}   cv accuracy = {s:.4f}")

best_k = ks[int(np.argmax(cv_scores))]   # first k with the highest score
print("\nbest k:", best_k)

knn = KNeighborsClassifier(n_neighbors=best_k)
knn.fit(X_train, y_train)
pred = knn.predict(X_test)
print("test accuracy:", round(accuracy_score(y_test, pred), 4))
print("confusion matrix:\n", confusion_matrix(y_test, pred))

# classify a brand new flower
new = sc.transform([[5.9, 3.0, 5.1, 1.8]])
print("new flower [5.9, 3.0, 5.1, 1.8] ->", iris.target_names[knn.predict(new)[0]])

plt.figure(figsize=(5.5, 4))
plt.plot(ks, cv_scores, "o-")
plt.xlabel("k (number of neighbours)")
plt.ylabel("cross-validation accuracy")
plt.title("Choosing k for KNN")
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig("../output/p5_knn_k.png", dpi=130)
