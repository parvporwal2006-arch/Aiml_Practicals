# Practical 6 - linear regression
# part A: simple regression (bmi -> progression), part B: multiple regression (all features)

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

d = load_diabetes()
X, y = d.data, d.target

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=11)

# ---- part A : one feature only (bmi is column 2)
bmi_train = X_train[:, [2]]
bmi_test = X_test[:, [2]]
simple = LinearRegression().fit(bmi_train, y_train)
p1 = simple.predict(bmi_test)
print("Simple regression")
print("  slope     :", round(simple.coef_[0], 2))
print("  intercept :", round(simple.intercept_, 2))
print("  R2        :", round(r2_score(y_test, p1), 3))
print("  RMSE      :", round(np.sqrt(mean_squared_error(y_test, p1)), 2))

# ---- part B : all 10 features
multi = LinearRegression().fit(X_train, y_train)
p2 = multi.predict(X_test)
print("\nMultiple regression")
for name, c in zip(d.feature_names, multi.coef_):
    print(f"  {name:4s} {c:9.2f}")
print("  intercept:", round(multi.intercept_, 2))
print("  R2   :", round(r2_score(y_test, p2), 3))
print("  MAE  :", round(mean_absolute_error(y_test, p2), 2))
print("  RMSE :", round(np.sqrt(mean_squared_error(y_test, p2)), 2))

fig, ax = plt.subplots(1, 2, figsize=(10, 4))
ax[0].scatter(bmi_test, y_test, s=15)
xs = np.linspace(bmi_test.min(), bmi_test.max(), 50).reshape(-1, 1)
ax[0].plot(xs, simple.predict(xs), "r")
ax[0].set_xlabel("bmi"); ax[0].set_ylabel("progression")
ax[0].set_title("Simple linear regression")
ax[1].scatter(y_test, p2, s=15)
ax[1].plot([y.min(), y.max()], [y.min(), y.max()], "r--")
ax[1].set_xlabel("actual"); ax[1].set_ylabel("predicted")
ax[1].set_title("Multiple regression: actual vs predicted")
plt.tight_layout()
plt.savefig("../output/p6_regression.png", dpi=130)
