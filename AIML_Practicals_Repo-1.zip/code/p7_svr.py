# Practical 7 - Support Vector Machine for regression (SVR)
# noisy sine curve so we can see what each kernel does

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.svm import SVR
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import mean_squared_error, r2_score

rng = np.random.RandomState(0)
X = np.sort(rng.uniform(0, 6, 120)).reshape(-1, 1)
y = np.sin(X).ravel() + rng.normal(0, 0.15, 120)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=5)

models = {
    "linear": SVR(kernel="linear", C=1.0, epsilon=0.1),
    "poly":   SVR(kernel="poly", degree=3, C=1.0, epsilon=0.1),
    "rbf":    SVR(kernel="rbf", C=10, gamma=0.5, epsilon=0.1),
}

xs = np.linspace(0, 6, 300).reshape(-1, 1)
fig, axes = plt.subplots(1, 3, figsize=(13, 3.8), sharey=True)
for ax, (name, m) in zip(axes, models.items()):
    m.fit(X_train, y_train)
    pred = m.predict(X_test)
    print(f"{name:6s} R2 = {r2_score(y_test, pred):6.3f}   MSE = {mean_squared_error(y_test,
pred):.4f}   support vectors = {len(m.support_)}")
    ax.scatter(X_train, y_train, s=10, color="grey")
    ax.plot(xs, m.predict(xs), "r")
    ax.set_title(f"SVR kernel = {name}")
plt.tight_layout()
plt.savefig("../output/p7_svr_kernels.png", dpi=130)

# tune C and gamma for the rbf kernel
grid = GridSearchCV(SVR(kernel="rbf", epsilon=0.1),
                    {"C": [0.1, 1, 10, 100], "gamma": [0.01, 0.1, 0.5, 1]}, cv=5)
grid.fit(X_train, y_train)
print("\nbest params:", grid.best_params_)
best = grid.best_estimator_
print("tuned rbf test R2:", round(r2_score(y_test, best.predict(X_test)), 3))
