# Practical 8 - regularization (Ridge and Lasso) to reduce overfitting
# a degree-12 polynomial on only 30 points overfits badly, penalties fix it

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

rng = np.random.RandomState(1)
X = rng.uniform(-3, 3, 60).reshape(-1, 1)
y = 0.5 * X.ravel() ** 2 - X.ravel() + rng.normal(0, 1.0, 60)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.5, random_state=2)

def make(reg):
    return make_pipeline(PolynomialFeatures(12, include_bias=False), StandardScaler(), reg)

models = {
    "No regularization": make(LinearRegression()),
    "Ridge (alpha=10)":  make(Ridge(alpha=10)),
    "Lasso (alpha=0.1)": make(Lasso(alpha=0.1, max_iter=50000)),
}

xs = np.linspace(-3, 3, 300).reshape(-1, 1)
fig, axes = plt.subplots(1, 3, figsize=(13, 3.8), sharey=True)
print(f"{'model':20s} {'train MSE':>10s} {'test MSE':>10s} {'zero coefs':>11s}")
for ax, (name, m) in zip(axes, models.items()):
    m.fit(X_train, y_train)
    tr = mean_squared_error(y_train, m.predict(X_train))
    te = mean_squared_error(y_test, m.predict(X_test))
    coefs = m[-1].coef_
    print(f"{name:20s} {tr:10.3f} {te:10.3f} {int(np.sum(np.abs(coefs) < 1e-8)):11d}")
    ax.scatter(X_train, y_train, s=12, color="grey")
    ax.plot(xs, m.predict(xs), "r")
    ax.set_ylim(-5, 12)
    ax.set_title(name)
plt.tight_layout()
plt.savefig("../output/p8_regularization.png", dpi=130)

# effect of alpha on ridge test error
print("\nRidge: alpha vs test MSE")
for a in [0.001, 0.1, 1, 10, 100, 1000]:
    m = make(Ridge(alpha=a)).fit(X_train, y_train)
    print(f"  alpha={a:<7} test MSE = {mean_squared_error(y_test, m.predict(X_test)):.3f}")
