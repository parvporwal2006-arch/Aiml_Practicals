# Practical 9 - object (people/vehicle) detection from CCTV footage
# usage:   python p9_cctv_detection.py                 -> makes a small demo clip and runs on it
#          python p9_cctv_detection.py my_cctv.mp4     -> runs on your own video
#
# Method: background subtraction (MOG2) finds anything that moves, contours
# give the bounding boxes. A HOG+SVM pedestrian detector is also shown (--hog)
# because it can label a box as "person" on real footage.

import sys
import cv2
import numpy as np

def make_demo_video(path, frames=150, w=480, h=270):
    """fake corridor camera: grey floor, two 'people' rectangles walking across"""
    out = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"MJPG"), 25, (w, h))
    rng = np.random.RandomState(0)
    for t in range(frames):
        img = np.full((h, w, 3), 110, np.uint8)
        cv2.rectangle(img, (0, 180), (w, h), (85, 85, 85), -1)       # floor
        cv2.rectangle(img, (200, 40), (280, 180), (130, 120, 100), -1)  # door
        # person 1 walks left -> right
        x1 = 20 + t * 3
        cv2.rectangle(img, (x1, 110), (x1 + 35, 200), (40, 40, 160), -1)
        # person 2 walks right -> left but only appears after frame 40
        if t > 40:
            x2 = w - 30 - (t - 40) * 3
            cv2.rectangle(img, (x2, 120), (x2 + 30, 205), (30, 140, 40), -1)
        img = cv2.add(img, rng.randint(0, 6, img.shape, dtype=np.uint8))   # sensor noise
        out.write(img)
    out.release()

video = sys.argv[1] if len(sys.argv) > 1 and not sys.argv[1].startswith("--") else None
use_hog = "--hog" in sys.argv
if video is None:
    video = "../output/demo_cctv.avi"
    make_demo_video(video)
    print("no video given, made demo clip:", video)

cap = cv2.VideoCapture(video)
fps = cap.get(cv2.CAP_PROP_FPS) or 25
W = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
H = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
print(f"video: {W}x{H}, {fps:.0f} fps, {int(cap.get(cv2.CAP_PROP_FRAME_COUNT))} frames")

bg = cv2.createBackgroundSubtractorMOG2(history=100, varThreshold=40, detectShadows=True)
kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
hog = cv2.HOGDescriptor()
hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())

writer = cv2.VideoWriter("../output/p9_annotated.avi", cv2.VideoWriter_fourcc(*"MJPG"), fps,
(W, H))
MIN_AREA = 600          # ignore tiny blobs (noise, leaves, etc)
saved = []
frame_no = 0
total = 0

while True:
    ok, frame = cap.read()
    if not ok:
        break
    frame_no += 1

    mask = bg.apply(frame)
    mask = cv2.threshold(mask, 200, 255, cv2.THRESH_BINARY)[1]   # drop shadow pixels (value 127)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    mask = cv2.dilate(mask, kernel, iterations=2)

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    boxes = [cv2.boundingRect(c) for c in contours if cv2.contourArea(c) > MIN_AREA]
    if frame_no < 15:     # background model still learning
        boxes = []

    for (x, y, w, h) in boxes:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
        cv2.putText(frame, "moving object", (x, y - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0,
255, 0), 1)

    if use_hog:
        rects, _ = hog.detectMultiScale(frame, winStride=(8, 8), padding=(8, 8), scale=1.05)
        for (x, y, w, h) in rects:
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)
            cv2.putText(frame, "person", (x, y + h + 15), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,
0, 255), 1)

    cv2.putText(frame, f"frame {frame_no}   objects: {len(boxes)}", (8, 18),
                cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1)
    writer.write(frame)
    total += len(boxes)

    if frame_no % 25 == 0:
        print(f"frame {frame_no:3d}: {len(boxes)} object(s) detected")
    if frame_no in (30, 60, 90, 120):
        saved.append(frame.copy())

cap.release()
writer.release()
print(f"\nprocessed {frame_no} frames, {total} detections in total")

if len(saved) == 4:
    small = [cv2.resize(f, (int(W * 0.75), int(H * 0.75))) for f in saved]
    grid = np.vstack([np.hstack(small[:2]), np.hstack(small[2:])])
    cv2.imwrite("../output/p9_frames.png", grid)
    print("saved sample frames (p9_frames.png) and annotated video (p9_annotated.avi) in ../output/")
